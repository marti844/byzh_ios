//
//  UserData.swift
//  twt
//
//  Created by Kean Shi on 2022/2/13.
//
import SwiftUI

//struct UserData: Identifiable {
//
//    let id: String = UUID().uuidString
//    var nickname: String
//    var sex: String
//    var pos: String
//    var qq: String
//    var wechat: String
//    var subject: String
//    var image: String
//
//}

class UserModel: ObservableObject {

    @Published var nickname: String = "地狱犬"
    @Published var gender: String = "男"
    @Published var qq: String = "12344"
    @Published var wechat: String = "12345"
    @Published var pwd: String = ""
    @Published var major: String = "马克思"
    @Published var campus: String = "加州分校"
    @Published var heading: String = "jjj"
    
    func changename(newname: String) {
        self.nickname = newname
    }
    
//    func getData() {
//        guard let url = URL(string: "https://180.76.100.8:8080/byzh/user/list") else { return }
//
//        let task = URLSession.shared.dataTask(with: url) { data, _, error in
//            guard let data = data, error == nil else { return }
//        }
//    }
}

//class Api {
//    func getData() {
//        guard let url = URL(string: "https://180.76.100.8:8080/byzh/user/list") else { return }
//
//        URLSession.shared.dataTask(with: url) { (data, _, _) in
//            let datas = try! JSONDecoder().decode([UserData].self, from: data!)
//            print(datas)
//        }
//        .resume()
//    }
//
//}



// MARK: - UserResponse
struct UserResponse: Codable {
    let flag: Bool?
    let data: [User]?
    
}

// MARK: - Datum
struct User: Codable {
    let id: Int?
    let postTime, content, posterID, startLocation: String?
    let destination, posterName, deadTime: String?
    let year, month, day, hour: Int?
    let minute, teamID, flag: Int?

    enum CodingKeys: String, CodingKey {
        case id, postTime, content
        case posterID = "posterId"
        case startLocation, destination, posterName, deadTime, year, month, day, hour, minute
        case teamID = "teamId"
        case flag
    }
    
//    init() {
//        let userData = UserViewModel()
//        userData.getData()
//    }
}


//struct User: Hashable, Codable, Identifiable {
//
//    var id: String?
//    var postTime: String?
//    var content: String?
//    var posterId: String?
//    var startLocation: String?
//    var destnation: String?
//    var posterName: String?
//    var deadTime: String?
//    var year: Int?
//    var month: Int?
//    var day: Int?
//    var hour: Int?
//    var minute: Int?
//    var teamId: Int?
//    var flag: Int?
    
//                "id": 1,
//                "postTime": "2022-03-15",
//                "content": "gender",
//                "posterId": "3021210045",
//                "startLocation": "123",
//                "destination": "321",
//                "posterName": "zztzztzzt",
//                "deadTime": "2022-03-15T05:30:57.000+00:00",
//                "year": 2022,
//                "month": 3,
//                "day": 15,
//                "hour": 13,
//                "minute": 30,
//                "teamId": 1,
//                "flag": 0
//
//    init() {
//        var userData = UserData()
//        var id = nil
//        let postTime = nil
//        let content = nil
//        let posterId = nil
//        let startLocation = nil
//        let destnation = nil
//        let posterName = nil
//        let deadTime = nil
//        let year = nil
//        let month = nil
//        let day = nil
//        let hour = nil
//        let minute = nil
//        let teamId = nil
//        let flag = nil
//        userData.getData()
//    }
//
//    [{"id":30214141,"nickname":"yr","gender":"M","qq":"1840543823","wechat":"12345","pwd":"12345","major":"智造","campus":"x","heading":"yr.jpg"},{"id":3021001824,"nickname":"yr","gender":"M","qq":"1840543823","wechat":"12345","pwd":"12345","major":"智造","campus":"x","heading":"yr.jpg"}]
//}

class UserViewModel: UIViewController, ObservableObject{
    let base = BaseNetwork(baseURL: URL(string: "http://101.201.36.172:520")!)
    
    @Published var users: [User] = []
    
    func getData() {
        Task {
            do {
                let resp = try await base.get("/posts/flag/0").decoded(type: UserResponse.self)
                users = resp.data ?? []
            } catch {
                print(error)
            }
        }
    }
    
//    func Login(id: String,pwd: String) {
//        Task {
//            do {
//                let resp = try await base.get("/users/login/\(id)/\(pwd)").decoded()(type: UserResponse.self)
//
//            }
//        }
//    }
    
    func getStudyData() {
        guard let url = URL(string: "http://180.76.100.8/study4posts") else { return }
        
        let task = URLSession.shared.dataTask(with: url) { [weak self] data, _, error in
            guard let data = data, error == nil else { return }
            
            do {
                let users = try JSONDecoder().decode([User].self, from: data)
                
                DispatchQueue.main.async {
                    self?.users = users
                }
            }
            catch {
                print(error)
            }
            
            
        }
        task.resume()
    }
}
